import { Http, Headers, RequestOptions } from '@angular/http';
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import { Events, Platform, Nav, Config, MenuController, ToastController, LoadingController, AlertController, ModalController } from 'ionic-angular';

import { SQLite, SQLiteObject } from '@ionic-native/sqlite';


/*
  Generated class for the DatabaseProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class DatabaseProvider {

  private db:SQLiteObject;
  private isOpen:boolean;

  constructor(public http: Http,public storage : SQLite,public platform: Platform ) {
    console.log('Hello DatabaseProvider Provider');
    platform.ready().then(() => {
      this.storage = new SQLite();
      this.storage.create({ name: "createCus.db", location: "default" }).then((db: SQLiteObject) => {
        this.db = db;
        console.log('DB :',this.db);
        db.executeSql("CREATE TABLE IF NOT EXISTS customer (id_customer int UNSIGNED NOT NULL, reference_no varchar(100) DEFAULT NULL, id_company int DEFAULT NULL,id_branch int DEFAULT NULL,id_village int DEFAULT NULL,title varchar(5) DEFAULT NULL,initials varchar(10) DEFAULT NULL,lastname varchar(32) DEFAULT NULL,firstname varchar(32) DEFAULT NULL,date_of_birth date DEFAULT NULL,date_of_wed date DEFAULT NULL,gender tinyint(1) DEFAULT NULL,id_address int UNSIGNED DEFAULT '0',id_employee int UNSIGNED DEFAULT '0',email varchar(128) DEFAULT NULL,mobile varchar(20) DEFAULT NULL,phone varchar(30) DEFAULT NULL,nominee_name varchar(50) DEFAULT NULL,nominee_relationship varchar(32) DEFAULT NULL,nominee_mobile varchar(20) DEFAULT NULL,cus_img varchar(50) DEFAULT NULL,pan varchar(15) DEFAULT NULL,pan_proof varchar(50) DEFAULT NULL,ispan_req tinyint UNSIGNED NOT NULL DEFAULT '0',voterid varchar(15) DEFAULT NULL,voterid_proof varchar(50) DEFAULT NULL,rationcard varchar(15) DEFAULT NULL,rationcard_proof varchar(50) DEFAULT NULL,comments varchar(200) DEFAULT NULL,username varchar(30) DEFAULT NULL,passwd varchar(32) DEFAULT NULL,profile_complete tinyint(1) DEFAULT '0',active tinyint UNSIGNED NOT NULL DEFAULT '1',is_new varchar(1) NOT NULL DEFAULT 'Y',date_add datetime DEFAULT CURRENT_TIMESTAMP,custom_entry_date date DEFAULT NULL,date_upd datetime DEFAULT NULL,added_by tinyint UNSIGNED NOT NULL DEFAULT '1',notification tinyint UNSIGNED NOT NULL DEFAULT '0',gst_number varchar(50) DEFAULT NULL,cus_ref_code varchar(45) DEFAULT NULL,is_refbenefit_crt_cus tinyint UNSIGNED NOT NULL DEFAULT '1',emp_ref_code varchar(45) DEFAULT NULL,is_refbenefit_crt_emp tinyint UNSIGNED NOT NULL DEFAULT '1',religion int DEFAULT NULL,kyc_status tinyint(1) NOT NULL DEFAULT '0',is_cus_synced tinyint(1) NOT NULL DEFAULT '0',last_sync_time datetime DEFAULT NULL,last_payment_on datetime DEFAULT NULL,is_vip tinyint(1) NOT NULL DEFAULT '0',cus_type tinyint(1) NOT NULL DEFAULT '1',send_promo_sms int NOT NULL DEFAULT '0',aadharid varchar(20) DEFAULT NULL,driving_license_no varchar(20) DEFAULT NULL,nominee_address1 varchar(150) DEFAULT NULL,nominee_address2 varchar(150) DEFAULT NULL)", []);
        this.isOpen = true;
        console.log('open : ',this.isOpen)
      }).catch((error) => {
        console.log('error :',error);
      })
    })
  }

  CreateUser(identification: number, name:string, lastname:string){
    return new Promise ((resolve, reject) => {
      let sql = "INSERT INTO customer (identification, name, lastname) VALUES (?, ?, ?)";
      this.db.executeSql(sql, [identification, name, lastname]).then((data) =>{
        resolve(data);
        console.log('sql insert data :',data)
      }, (error) => {
        reject(error);
      });
    });
  }

  GetAllUsers(){
    return new Promise ((resolve, reject) => {
      this.db.executeSql("SELECT * FROM users", []).then((data) => {
        let arrayUsers = [];
        if (data.rows.length > 0) {
          for (var i = 0; i < data.rows.length; i++) {
            arrayUsers.push({
              id: data.rows.item(i).id,
              identification: data.rows.item(i).identification,
              name: data.rows.item(i).name,
              lastname: data.rows.item(i).lastname
            });            
          }          
        }
        resolve(arrayUsers);
      }, (error) => {
        reject(error);
      })
    })
  }
}
